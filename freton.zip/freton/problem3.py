def print_chessboard(chessboard):
    print("Chessboard:")
    for row in chessboard:
        print(" ".join(map(str, row)))
    print()

def solve(mat, vis, row, col, r, c, dir, path_length):
    global cnt

    size = len(mat)

    if row < 0 or col < 0 or row >= size or col >= size:
        return

    if row == r and col == c and path_length > 0:
        cnt += 1
        return

    if mat[row][col] == 1:
        if vis[row][col] != 1:
            vis[row][col] = 1

            if dir == 'd':
                solve(mat, vis, row, col + 1, r, c, 'r', path_length + 1)
            elif dir == 'r':
                solve(mat, vis, row - 1, col, r, c, 'u', path_length + 1)
            elif dir == 'u':
                solve(mat, vis, row, col - 1, r, c, 'l', path_length + 1)
            elif dir == 'l':
                solve(mat, vis, row + 1, col, r, c, 'd', path_length + 1)

            vis[row][col] = 0

        if dir == 'd':
            solve(mat, vis, row + 1, col, r, c, dir, path_length)
        elif dir == 'r':
            solve(mat, vis, row, col + 1, r, c, dir, path_length)
        elif dir == 'u':
            solve(mat, vis, row - 1, col, r, c, dir, path_length)
        elif dir == 'l':
            solve(mat, vis, row, col - 1, r, c, dir, path_length)
    else:
        if dir == 'd':
            solve(mat, vis, row + 1, col, r, c, dir, path_length)
        elif dir == 'r':
            solve(mat, vis, row, col + 1, r, c, dir, path_length)
        elif dir == 'u':
            solve(mat, vis, row - 1, col, r, c, dir, path_length)
        elif dir == 'l':
            solve(mat, vis, row, col - 1, r, c, dir, path_length)

def main():
    global cnt
    cnt = 0
    size = 9
    chessboard = [[0] * size for _ in range(size)]

    soldier_count = int(input("Enter number of soldiers: "))

    for i in range(1, soldier_count + 1):
        coords = input(f"Enter coordinates for soldier {i} (format: x,y): ").split(",")
        x = int(coords[0]) - 1
        y = int(coords[1]) - 1

        if 0 <= x < size and 0 <= y < size:
            chessboard[y][x] = 1
        else:
            print(f"Invalid coordinates. Please enter values between 1 and {size}")
            i -= 1

    print_chessboard(chessboard)

    coords = input("Enter the coordinates for your special castle (format: x,y): ").split(",")
    start_x = int(coords[0]) - 1
    start_y = int(coords[1]) - 1

    vis = [[0] * size for _ in range(size)]
    
    initial_path = [[start_x, start_y]]
    solve(chessboard, vis, start_y, start_x, start_y, start_x, 'd', 0)

    print("Total unique paths:", cnt)

if __name__ == "__main__":
    main()
