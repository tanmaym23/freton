def distribute_apple():
    apple_weights = []
    while True:
            weight = int(input("Enter apple weight in grams (-1 to stop): "))
            if weight == -1:
                break
            apple_weights.append(weight)

    total_weight = sum(apple_weights)

    ram_share = 0.5 * total_weight
    sham_share = 0.3 * total_weight
    rahim_ = 0.2 * total_weight

    ram=[]
    sham=[]
    rahim=[]

    def solution(remaining_share, ind, current_distribution):
        if remaining_share == 0:
            ans.append(current_distribution[:])
            return
        for i in range(ind, len(apple_weights)):
            if i > ind and apple_weights[i] == apple_weights[i - 1]:
                continue
            if apple_weights[i] > remaining_share:
                break
            current_distribution.append(apple_weights[i])
            solution(remaining_share - apple_weights[i], i + 1, current_distribution)
            current_distribution.pop()

    ans = []
    apple_weights.sort(reverse=True)
    solution(ram_share, 0, [])
    return ans
if __name__ == "__main__":
    ram = distribute_apple()
    if ram:
        print("One valid distribution:")
        print(ram[0])
    else:
        print("No valid distribution found.")